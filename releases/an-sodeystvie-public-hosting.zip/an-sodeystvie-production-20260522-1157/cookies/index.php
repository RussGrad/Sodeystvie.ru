<?php

declare(strict_types=1);

$pageTitle = 'Cookies — Содействие';
$currentNav = '';

require __DIR__ . '/../includes/header.php';
?>
<main class="page-main page-main--inner" id="main">
    <div class="container">
        <h1 class="page-main__heading">Согласие на использование cookies</h1>
        <p class="page-main__lead">Страница в разработке. Текст согласия будет добавлен после согласования.</p>
    </div>
</main>
<?php
require __DIR__ . '/../includes/footer.php';

