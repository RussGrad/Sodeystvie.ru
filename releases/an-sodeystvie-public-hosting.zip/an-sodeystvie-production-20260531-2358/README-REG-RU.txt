Содействие — витрина для REG.RU / ispmgr
========================================

1) В панели укажите корень сайта на эту папку (куда распаковали архив):
   внутри должны лежать index.php, css/, includes/, catalog/ и т.д.

2) Скопируйте env.example.txt в файл с именем .env в ЭТОЙ ЖЕ папке (рядом с index.php).
   Заполните CRM_API_BASE и CRM_PUBLIC_BASE — HTTPS-URL вашего Nest API (an-realty-crm).
   Пример:
     CRM_API_BASE="https://api.ваш-домен.ru"
     CRM_PUBLIC_BASE="https://api.ваш-домен.ru"

3) PHP: версия 8.1+ желательно 8.3. Нужны curl или allow_url_fopen для запросов к API.

4) Не заливайте сюда node_modules, src/, prisma/ — они для разработки, на shared не нужны.

Каталог: GET {CRM_API_BASE}{CRM_LISTINGS_PATH} (по умолчанию /api/public/listings)
